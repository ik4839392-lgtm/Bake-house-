BAKE HOUSE LAHORE: Customer + Staff + Admin + WhatsApp API (Render free)

LINKS (deploy ke baad / after deploy)
  https://YOUR-APP.onrender.com/        customer  (sab ko dein / share with everyone)
  https://YOUR-APP.onrender.com/staff   staff board (STAFF_PIN)
  https://YOUR-APP.onrender.com/admin   admin: orders, menu, settings (ADMIN_PIN)

1) RENDER PAR LAGANA (free)
  a. GitHub par naya private repo banayein, is poore folder ko upload karein.
  b. render.com > New > Blueprint > apna repo chunein. Render render.yaml parh lega (plan: free).
  c. Environment variables mein ADMIN_PIN aur STAFF_PIN zaroor likhein (alag alag, mushkil PIN).
  d. Deploy ke baad aapka *.onrender.com link mil jata hai.
  Note: free service 15 minute idle rehne par so jati hai; pehla order kholne mein ~50 second lag sakte hain.

2) DATA MEHFOOZ RAKHNA (zaroori / important)
  Render free par files restart par mit jati hain. Orders aur menu bachane ke liye free Upstash Redis lein:
  upstash.com > Create Database (Redis, free) > "REST API" tab se
  UPSTASH_REDIS_REST_URL aur UPSTASH_REDIS_REST_TOKEN Render env mein daal dein.
  Iske baghair orders/menu restart par ghayab ho sakte hain.

3) WHATSAPP API (Meta Cloud API, free tier)
  developers.facebook.com > Create App > Business > WhatsApp. Wahan se
    WA_PHONE_ID = Phone number ID
    WA_TOKEN    = permanent access token (System User token; 24 ghante wala test token jaldi expire hota hai)
  Render env mein dono daalein. Admin > Settings mein apna WhatsApp number (923xxxxxxxxx) likhein.
  Kya hota hai: naya order aane par aap ko WhatsApp message; order "Tayyar" ya "Cancel" karne par customer ko message.
  Hudood: Meta sirf 24 ghante ke andar (jab us number ne aap ko message kiya ho) free text allow karta hai.
  Is se bahar message ke liye Meta ka approved template chahiye. Test number ko pehle recipient list mein add karna parta hai.
  Agar API na lagayen to bhi sab chalta hai: customer ko "WhatsApp par bhi bhejein" ka button milta hai.

4) ROZANA ISTEMAAL
  Admin > Menu: item, price, "Hai" (stock) badlein > Save. Foran live. Admin > Settings: naam, WhatsApp, fee, bank, announcement.
  Staff: /staff par PIN, naye order par beep, button dabate jayein: Naya > Ban raha > Tayyar > Mukammal.

HUDOOD / LIMITS
  Odoo se stock/price automatic nahi aata (haath se). Tasveer abhi emoji hai. Online payment screenshot WhatsApp chat mein jata hai.
  PIN kisi ko na dein; 1 minute mein 10 galat koshishon ke baad rok lag jati hai.
