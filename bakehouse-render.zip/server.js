// Bake House Lahore: zero-dependency Node server (Node 18+). Render free web service.
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os');
const E=process.env,PORT=E.PORT||3000,FILE=path.join(os.tmpdir(),'bakehouse.json');
const U=E.UPSTASH_REDIS_REST_URL,UT=E.UPSTASH_REDIS_REST_TOKEN;
let DB={menu:JSON.parse(fs.readFileSync(path.join(__dirname,'seed.json'))),orders:[]};
const nw=v=>{let d=String(v||'').replace(/\D/g,'');if(d.startsWith('00'))d=d.slice(2);if(d.startsWith('0'))d='92'+d.slice(1);return d};
async function load(){try{if(U){const r=await(await fetch(U+'/get/bakehouse',{headers:{Authorization:'Bearer '+UT}})).json();if(r.result)DB=JSON.parse(r.result)}else DB=JSON.parse(fs.readFileSync(FILE))}catch(e){}}
let tm;const save=()=>{clearTimeout(tm);tm=setTimeout(async()=>{const s=JSON.stringify(DB);try{if(U)await fetch(U,{method:'POST',headers:{Authorization:'Bearer '+UT},body:JSON.stringify(['SET','bakehouse',s])});else fs.writeFileSync(FILE,s)}catch(e){console.log('save fail',e.message)}},300)};
async function wa(to,text){to=nw(to);if(!E.WA_TOKEN||!E.WA_PHONE_ID||!to)return;
  try{const r=await fetch(`https://graph.facebook.com/v21.0/${E.WA_PHONE_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+E.WA_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to,type:'text',text:{body:text}})});if(!r.ok)console.log('WA',r.status,await r.text())}catch(e){console.log('WA err',e.message)}}
const role=q=>{const p=q.headers['x-pin']||'';return E.ADMIN_PIN&&p===E.ADMIN_PIN?'admin':E.STAFF_PIN&&p===E.STAFF_PIN?'staff':''};
const bad={};const limited=ip=>{const n=Date.now(),b=bad[ip]=(bad[ip]||[]).filter(t=>n-t<6e4);return b.length>=10};
const money=n=>'Rs. '+Math.round(n).toLocaleString('en-US');
const PAY={cash:'Cash',card:'Card',online:'Online transfer'};
const J=(s,c,o)=>{s.writeHead(c,{'Content-Type':'application/json','Cache-Control':'no-store'});s.end(JSON.stringify(o))};
const body=q=>new Promise((ok,no)=>{let b='';q.on('data',c=>{b+=c;if(b.length>3e5){no();q.destroy()}});q.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch(e){no()}})});
const PAGES={'/':'index.html','/staff':'staff.html','/admin':'admin.html','/app.js':'app.js','/style.css':'style.css'};
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css'};
http.createServer(async(q,s)=>{
  const u=new URL(q.url,'http://x'),p=u.pathname,ip=q.headers['x-forwarded-for']||q.socket.remoteAddress||'';
  try{
  if(p==='/api/menu'&&q.method==='GET')return J(s,200,DB.menu);
  if(p==='/api/track')return J(s,200,{status:(DB.orders.find(o=>o.id===u.searchParams.get('id'))||{}).status||null});
  if(p==='/api/order'&&q.method==='POST'){
    const b=await body(q),m=DB.menu,lines=[];
    for(const x of Array.isArray(b.items)?b.items.slice(0,40):[]){const it=m.items.find(i=>i.b===x.b),n=Math.floor(+x.q);if(it&&it.s&&n>0&&n<=50)lines.push({b:it.b,n:it.n,q:n,p:it.p})}
    const name=String(b.name||'').trim().slice(0,80),phone=String(b.phone||'').trim().slice(0,20),type=b.type==='pickup'?'pickup':'delivery',address=String(b.address||'').trim().slice(0,300);
    if(!lines.length||!name||phone.replace(/\D/g,'').length<10||(type==='delivery'&&!address))return J(s,400,{error:'Naam, phone, address aur items zaroori hain · Name, phone, address and items are required'});
    const sub=lines.reduce((a,l)=>a+l.p*l.q,0),fee=type==='delivery'?+m.fee||0:0,pay=PAY[b.pay]?b.pay:'cash';
    const o={id:'ORD-'+Date.now().toString(36).toUpperCase().slice(-6)+Math.floor(Math.random()*36).toString(36).toUpperCase(),at:Date.now(),status:'new',name,phone,address,type,pay:PAY[pay],txn:String(b.txn||'').slice(0,60),bank:String(b.bank||'').slice(0,60),loc:/^https:\/\/maps\.google\.com\/\?q=/.test(b.loc||'')?b.loc:'',lines,sub,fee,total:sub+fee};
    DB.orders.unshift(o);DB.orders=DB.orders.slice(0,500);save();
    wa(m.wa,`*Naya order ${o.id}*\n${name} · ${phone}\n${type==='pickup'?'Pickup':address}\n${PAY[pay]}${o.txn?' · Txn '+o.txn:''}\n\n`+lines.map(l=>`• ${l.n} x ${l.q} = ${money(l.p*l.q)}`).join('\n')+`\n\n*Total: ${money(o.total)}*`+(o.loc?'\n'+o.loc:''));
    return J(s,200,{id:o.id,total:o.total});
  }
  if(p.startsWith('/api/')){
    if(limited(ip))return J(s,429,{error:'Bohat koshishen · Too many tries'});
    const r=role(q);if(!r){(bad[ip]=bad[ip]||[]).push(Date.now());return J(s,401,{error:'PIN galat hai · Wrong PIN'})}
    if(p==='/api/orders')return J(s,200,{role:r,orders:DB.orders});
    if(p==='/api/status'&&q.method==='POST'){const b=await body(q),o=DB.orders.find(x=>x.id===b.id);if(!o||!['new','preparing','ready','done','cancel'].includes(b.status))return J(s,400,{error:'Order nahi mila'});
      o.status=b.status;save();
      if(b.status==='ready')wa(o.phone,`Assalam o Alaikum ${o.name}! Aapka order ${o.id} tayyar hai. Your order is ready. - ${DB.menu.shop}`);
      if(b.status==='cancel')wa(o.phone,`Aapka order ${o.id} cancel ho gaya. Your order was cancelled. Rabta: +${DB.menu.wa}`);
      return J(s,200,{ok:1})}
    if(p==='/api/menu'&&q.method==='POST'){if(r!=='admin')return J(s,403,{error:'Sirf admin · Admin only'});
      const b=await body(q),seen={},items=(b.items||[]).map(x=>({b:String(x.b||'').trim(),n:String(x.n||'').trim(),c:String(x.c||'').trim(),p:Math.max(0,+x.p||0),i:String(x.i||''),e:String(x.e||''),s:!!x.s})).filter(x=>x.b&&x.n&&!seen[x.b]&&(seen[x.b]=1));
      DB.menu={shop:String(b.shop||'').trim()||'Bake House',own:String(b.own||''),ann:String(b.ann||''),wa:nw(b.wa),email:'',fee:Math.max(0,+b.fee||0),bank:String(b.bank||''),items};save();return J(s,200,{ok:1})}
    return J(s,404,{error:'Nahi mila'});
  }
  const f=PAGES[p];if(!f){s.writeHead(404);return s.end('Not found')}
  s.writeHead(200,{'Content-Type':MIME[path.extname(f)],'Cache-Control':'no-cache'});fs.createReadStream(path.join(__dirname,'public',f)).pipe(s);
  }catch(e){J(s,400,{error:'Request theek nahi · Bad request'})}
}).listen(PORT,async()=>{await load();console.log('Bake House on',PORT)});
